
INSERT INTO FILM (IDFILM, TITOLO, ANNOUSCITA, CODICEREGISTA)
VALUES 
(1,	'AVATAR'	,2009,	'1R'),
(2,	'AVENGERS',	2012,	'2R'),
(3,	'INCEPTION',	2010,	'3R'),
(4,	'INTERSTELLAR',	2014,	'3R'),
(5,	'IRON MAN', 	2008,	'6R'),
(6,	'SPIDERMAN NO WAY HOME',	2021,	'5R'),
(7,	'LE ALI DELLA LIBERTA',	1994,	'7R'),
(8,	'C era una volta in America',	1984,	'8R'),
(9,	'Il cavaliere oscuro',	2008,	'3R'),
(10,'Via col vento',	1939,	'10R'),
(11,'Salvate il soldato Ryan',	1998,	'9R')



INSERT INTO ATTORI(CODICEATTORE ,NOMEATTORE, COGNOMEATTORE, ANNONASCITAATTORE, NUMEROFILM)
VALUES 
('1A','Leonardo',	'DiCaprio',	1972,	8),
('2A','mat' ,	'McConaughey',	1976,	4),
('3A', 'Robert' ,	'Downey Jr.',	1958,	3),
('4A', 'Tom' ,	'Holland',	1996	,5),
('5A','Tim' ,	'Robbins',	1958,	8),
('6A', 'Robert', 	'De Niro',	1958,	55),
('7A', 'Christian', 	'Bale',	1976,	44),
('8A', 'Clark' ,	'Gable'	,	1958,	6),
('9A', 'Tom' ,	'Hanks',	1979,	3),
('10A', 'Leonardo',	'Matthew',	1985,	65),
('11A','Sam',	'Worthington',	1958,	10)


INSERT INTO REGISTI ( CODICEREGISTA, NOMEREGISTA, COGNOMEREGISTA, DATANASCITAREGISTA, FILMGIRATI )
VALUES 
('1R', 'james',	'CAMEROON',		1958,	23 ),
('2R',  ' joss'	,'Joss Whedon'	,	1996,	56 ),
('3R',   'CHRISTOPHER', 	'NOLAN',		1958, 54 ),
('4R',   'Almerigo',	'americ',	1958,	4 ),
('5R',   'Jon',	'watts'	,       	        1976,	5 ),
('6R',   'Jon'	,'Favreau',	        1958,	55 ),
('7R' ,  'Frank' ,	'Darabont',	1972,	7 ),
('8R',   'sergio',	'Leone'	,	1976,	11 ),
('9R' ,  'Steven' ,	'Spielberg',	1958,	33 ),
('10R' ,  'Victor',	'Fleming',	1996,	57 )



INSERT INTO ATTOREFILM ( IDFILM, CODICEATTORE,	RUOLO )
VALUES 
(7,	'3A',	'PROTAGONISTA' ),
(2,	'7A',	'ANTAGONISTA' ),
(6,	'3A',	'COMPARS'),
(3,	'1A',	'PROTAGONISTA' ),
(3,	'7A',	'COMPARSA' ),
(6,	'2A',	'PROTAGONISTA' )


SELECT *
FROM FILM

SELECT *
FROM ATTORI

SELECT *
FROM REGISTI

SELECT *
FROM ATTOREFILM